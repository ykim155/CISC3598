package Lab3;

public class tank extends vehicle{
    
}
