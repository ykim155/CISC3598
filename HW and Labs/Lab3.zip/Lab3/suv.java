package Lab3;

public class suv extends vehicle{
    
}
