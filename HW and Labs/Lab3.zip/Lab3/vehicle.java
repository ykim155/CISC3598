package Lab3;

public class vehicle 
{
   int speed;
   int milesPerGallon;
   
   public void setSpeed(int sp)
   {
	   speed = sp;
   }
   
   public void turnLeft()
   {
	   System.out.println("Turning Left!");
   }
   
   public void turnRight()
   {
	   System.out.println("Turning Right!");
   }
}
