package Lab3;

public class trolley extends vehicle{
    
}
